import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Services.UPower

import qs.utils

// Battery level + charging indicator. Reads Quickshell's built-in UPower
// integration, so it needs the upower daemon running on the system.
Item {
  id: root

  Layout.preferredWidth: parent.width
  Layout.preferredHeight: 56
  Layout.alignment: Qt.AlignHCenter

  readonly property var device: UPower.displayDevice
  readonly property real pct: device?.percentage ?? 0
  readonly property bool charging: device?.state === UPowerDeviceState.Charging
  readonly property bool low: pct < 0.15 && !charging

  ColumnLayout {
    anchors.centerIn: parent
    spacing: 4

    Rectangle {
      id: body
      Layout.alignment: Qt.AlignHCenter
      width: 20
      height: 34
      radius: 6
      color: "transparent"
      border.color: Theme.mainColor
      border.width: 1.5

      // Nub on top of the battery outline.
      Rectangle {
        width: 8
        height: 3
        radius: 1
        color: Theme.mainColor
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: -4
      }

      // Fill level.
      Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 3
        height: (parent.height - 6) * root.pct
        radius: 2
        color: root.low ? "#e06c75" : Theme.mainColor

        Behavior on height { NumberAnimation { duration: 300 } }
      }

      // Little bolt overlay while charging.
      Text {
        visible: root.charging
        text: "\u26A1"
        color: Theme.accentColor
        font.pixelSize: 10
        anchors.centerIn: parent
      }
    }

    Text {
      Layout.alignment: Qt.AlignHCenter
      text: Math.round(root.pct * 100)
      color: root.low ? "#e06c75" : Theme.mainColor
      font.pixelSize: 12
    }
  }

  // Wire this up to whatever battery/power stats tool you use, e.g.:
  // MouseArea {
  //   anchors.fill: parent
  //   onClicked: Quickshell.execDetached(["your-battery-monitor"])
  // }
}
