import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Hyprland

import qs.utils

// Power glyph that expands a small flyout with lock/logout/reboot/shutdown.
// Adjust the commands to whatever your system actually uses (loginctl,
// systemctl, a session-lock binary, etc).
Item {
  id: root

  Layout.preferredWidth: parent.width
  Layout.preferredHeight: expanded ? 40 + menu.implicitHeight : 40
  Layout.alignment: Qt.AlignHCenter

  property bool expanded: false

  Behavior on Layout.preferredHeight { NumberAnimation { duration: 150 } }

  Text {
    id: icon
    anchors.horizontalCenter: parent.horizontalCenter
    anchors.top: parent.top
    text: "\uf011" // power glyph
    font.pixelSize: 16
    color: root.expanded ? Theme.accentColor : Theme.mainColor

    MouseArea {
      anchors.fill: parent
      anchors.margins: -8
      onClicked: root.expanded = !root.expanded
    }
  }

  ColumnLayout {
    id: menu
    visible: root.expanded
    anchors.top: icon.bottom
    anchors.topMargin: 10
    anchors.horizontalCenter: parent.horizontalCenter
    spacing: 10

    Repeater {
      model: [
        { glyph: "\uf023", cmd: ["loginctl", "lock-session"] },
        { glyph: "\uf2f5", cmd: ["hyprctl", "dispatch", "'hl.dsp.exit()'"] },
        { glyph: "\uf021", cmd: ["systemctl", "reboot"] },
        { glyph: "\uf011", cmd: ["systemctl", "poweroff"] },
      ]

      Text {
        text: modelData.glyph
        font.pixelSize: 14
        color: Theme.mainColor
        Layout.alignment: Qt.AlignHCenter

        MouseArea {
          anchors.fill: parent
          anchors.margins: -6
          onClicked: {
            Quickshell.execDetached(modelData.cmd)
            root.expanded = false
          }
        }
      }
    }
  }
}
