import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Networking

import qs.utils

// WiFi glyph reflecting connection state + rough signal strength.
//
// NOTE: Quickshell.Networking is a newer, less-documented module than
// Hyprland/UPower/Bluetooth. The property names below (activeAccessPoint,
// ssid, strength) are the ones exposed by WifiDevice as of recent
// Quickshell versions, but if this errors on load, run `qs -c <config> `
// with verbose logging or check `qmlls`/the in-editor LSP hints against
// your installed Quickshell version — the network module is still
// actively evolving.
Item {
  id: root

  Layout.preferredWidth: parent.width
  Layout.preferredHeight: 40
  Layout.alignment: Qt.AlignHCenter

  readonly property var wifiDevice: {
    for (const dev of Networking.devices.values) {
      if (dev.type === NetworkDeviceType.Wifi) return dev
    }
    return null
  }

  readonly property var activeAp: wifiDevice?.activeAccessPoint ?? null
  readonly property bool connected: activeAp !== null
  readonly property real strength: activeAp?.strength ?? 0 // 0-100

  function glyph() {
    if (!root.wifiDevice) return "\uf05e"   // no adapter
    if (!root.connected) return "\uf6ac"    // disconnected
    if (root.strength > 75) return "\uf1eb" // full
    if (root.strength > 40) return "\uf6ab" // medium
    return "\uf6aa"                         // weak
  }

  ColumnLayout {
    anchors.centerIn: parent
    spacing: 2

    Text {
      Layout.alignment: Qt.AlignHCenter
      text: root.glyph()
      font.pixelSize: 16
      color: Theme.mainColor
      opacity: root.connected ? 1 : 0.35
    }

    Text {
      visible: root.connected
      Layout.alignment: Qt.AlignHCenter
      text: Math.round(root.strength) + "%"
      color: Theme.mainColor
      opacity: 0.6
      font.pixelSize: 9
    }
  }

  MouseArea {
    anchors.fill: parent
    onClicked: Quickshell.execDetached(["nm-connection-editor"])
  }
}
