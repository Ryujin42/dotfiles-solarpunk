import QtQuick
import QtQuick.Layouts

import qs.utils

// Stacked HH / MM clock, sized for a narrow vertical bar.
// Uses a plain Timer + Date rather than any Quickshell-specific clock
// service, so it has no extra dependencies.
Item {
  id: root

  Layout.preferredWidth: parent.width
  Layout.preferredHeight: 50
  Layout.alignment: Qt.AlignHCenter

  property date now: new Date()
  property bool showSeconds: false

  Timer {
    interval: root.showSeconds ? 1000 : 1000 * (60 - root.now.getSeconds())
    running: true
    repeat: true
    triggeredOnStart: true
    onTriggered: root.now = new Date()
  }

  ColumnLayout {
    anchors.centerIn: parent
    spacing: 0

    Text {
      Layout.alignment: Qt.AlignHCenter
      text: Qt.formatTime(root.now, "hh")
      color: Theme.mainColor
      font.pixelSize: 14
      font.weight: 600
    }

    Text {
      Layout.alignment: Qt.AlignHCenter
      text: Qt.formatTime(root.now, "mm")
      color: Theme.mainColor
      font.pixelSize: 14
      font.weight: 600
    }

    Text {
      visible: root.showSeconds
      Layout.alignment: Qt.AlignHCenter
      text: Qt.formatTime(root.now, "ss")
      color: Theme.mainColor
      opacity: 0.5
      font.pixelSize: 10
    }
  }

  // Hover/click for the full date — swap for a Tooltip type if you have one.
  MouseArea {
    id: hoverArea
    anchors.fill: parent
    hoverEnabled: true
  }

  Text {
    visible: hoverArea.containsMouse
    text: Qt.formatDate(root.now, "dddd, MMM d")
    color: Theme.mainColor
    font.pixelSize: 10
    anchors.left: parent.right
    anchors.leftMargin: 8
    anchors.verticalCenter: parent.verticalCenter
  }
}
